MySensorsArduinoExamples
=======

This repository includes the Examples, which where included in MySensors 1.x releases, that depends on external libraries.

As the libraries that is needed for these examples are not maintained by, or distributed with MySensors, they have been moved here from their original sources and potentially modified to work with the MySensorsArduinoExamples sketches. If you are going to use the examples herein, it is strongly recommended you also use the libraries from this repository. 
