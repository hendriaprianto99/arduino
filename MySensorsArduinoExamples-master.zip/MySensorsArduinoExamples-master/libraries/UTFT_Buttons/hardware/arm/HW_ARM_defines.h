#define bitmapdatatype unsigned short*
