#define bitmapdatatype unsigned int*
